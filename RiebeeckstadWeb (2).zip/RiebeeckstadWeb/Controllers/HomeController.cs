using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using RiebeeckstadWeb.Models;

namespace RiebeeckstadWeb.Controllers;

public class HomeController : Controller
{
    /// <summary>Welcome screen.</summary>
    public IActionResult Index() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}